import numpy as np
from nn.init import initialize

class Layer:
    """Base class for all neural network modules.
    You must implement forward and backward method to inherit this class.
    All the trainable parameters have to be stored in params and grads to be
    handled by the optimizer.
    """
    def __init__(self):
        self.params, self.grads = dict(), dict()

    def forward(self, *input):
        raise NotImplementedError
        
    def backward(self, *input):
        raise NotImplementedError


class Linear(Layer):
    """Linear (fully-connected) layer.

    Args:
        - in_dims (int): Input dimension of linear layer.
        - out_dims (int): Output dimension of linear layer.
        - init_mode (str): Weight initalize method. See `nn.init.py`.
          linear|normal|xavier|he are the possible options.
        - init_scale (float): Weight initalize scale for the normal init way.
          See `nn.init.py`.
        
    """
    def __init__(self, in_dims, out_dims, init_mode="linear", init_scale=1e-3):
        super().__init__()

        self.params["w"] = initialize((in_dims, out_dims), init_mode, init_scale) 
        self.params["b"] = initialize(out_dims, "zero") 
    
    def forward(self, x):
        """Calculate forward propagation.

        Returns:
            - out (numpy.ndarray): Output feature of this layer.
        """
        ######################################################################
        # TODO: Linear 레이어의 forward propagation 구현.
        ######################################################################
        self.params["x"]=x
        out = np.dot(x,self.params["w"]) + self.params["b"]
        ######################################################################
        #                          END OF YOUR CODE                          #
        ######################################################################
        return out

    def backward(self, dout):
        """Calculate backward propagation.

        Args:
            - dout (numpy.ndarray): Derivative of output `out` of this layer.
        
        Returns:
            - dx (numpy.ndarray): Derivative of input `x` of this layer.
        """
        ######################################################################
        # TODO: Linear 레이어의 backward propagation 구현.
        ######################################################################
        dx = np.dot(dout,self.params['w'].T)
        dw = np.dot(self.params['x'].T,dout)
        db = np.array([np.sum(raw) for raw in dout.T])
        ######################################################################
        #                          END OF YOUR CODE                          #
        ######################################################################
        self.grads["x"] = dx
        self.grads["w"] = dw
        self.grads["b"] = db
        return dx


class ReLU(Layer):
    def __init__(self):
        super().__init__()

    def forward(self, x):
        ######################################################################
        # TODO: ReLU 레이어의 forward propagation 구현.
        ######################################################################
        self.params['mask'] = (x<=0)
        out = x.copy()
        out[self.params['mask']] = 0

        ######################################################################
        #                          END OF YOUR CODE                          #
        ######################################################################
        return out

    def backward(self, dout):
        ######################################################################
        # TODO: ReLU 레이어의 backward propagation 구현.
        ######################################################################
   
        dout[self.params['mask']] = 0
        
        dx = dout
        ######################################################################
        #                          END OF YOUR CODE                          #
        ######################################################################
        self.grads["x"] = dx
        return dx


class Sigmoid(Layer):
    def __init__(self):
        super().__init__()

    def forward(self, x):
        ######################################################################
        # TODO: Sigmoid 레이어의 forward propagation 구현.
        ######################################################################
        out = 1 / (1 + np.exp(-x))
        self.params['out'] = out
        ######################################################################
        #                          END OF YOUR CODE                          #
        ######################################################################
        return out

    def backward(self, dout):
        ######################################################################
        # TODO: Sigmoid 레이어의 backward propagation 구현.
        ######################################################################
        dx = dout * (1.0 - self.params['out']) * self.params['out']
        ######################################################################
        #                          END OF YOUR CODE                          #
        ######################################################################
        self.grads["x"] = dx
        return dx


class Tanh(Layer):
    def __init__(self):
        super().__init__()

    def forward(self, x):
        ######################################################################
        # TODO: Tanh 레이어의 forward propagation 구현.
        ######################################################################
        
        out = np.tanh(x)
        self.params['out'] = out
        ######################################################################
        #                          END OF YOUR CODE                          #
        ######################################################################
        return out

    def backward(self, dout):
        ######################################################################
        # TODO: Tanh 레이어의 backward propagation 구현.
        ######################################################################
        
        dx = dout*(1-self.params['out']**2)
        ######################################################################
        #                          END OF YOUR CODE                          #
        ######################################################################
        self.grads["x"] = dx
        return dx


class SoftmaxCELoss(Layer):
    """Softmax and cross-entropy loss layer.
    """
    def __init__(self):
        super().__init__()

    def forward(self, x, y):
        """Calculate both forward and backward propagation.
        
        Args:
            - x (numpy.ndarray): Pre-softmax (score) matrix (or vector).
            - y (numpy.ndarray): Label of the current data feature.

        Returns:
            - loss (float): Loss of current data.
            - dx (numpy.ndarray): Derivative of pre-softmax matrix (or vector).
        """
        ######################################################################
        # TODO: Softmax cross-entropy 레이어의 구현. 
        #        
        # NOTE: 이 메소드에서 forward/backward를 모두 수행하고, loss와 gradient (dx)를 
        # 리턴해야 함.
        ######################################################################
        soft = []
        for index,raw in enumerate(x):
            sum = np.sum(np.exp(raw))
            soft.append(np.exp(raw)/sum)
        soft=np.array(soft)
        m = y.shape[0]
        log = -np.log(soft[range(m),y])
        
        loss = np.sum(log) / m
        
        soft[range(m),y] -= 1
        dx = soft/m
        ######################################################################
        #                          END OF YOUR CODE                          #
        ######################################################################
        return loss, dx
    
    
class Conv2d(Layer):
    """Convolution layer.

    Args:
        - in_dims (int): Input dimension of conv layer.
        - out_dims (int): Output dimension of conv layer.
        - ksize (int): Kernel size of conv layer.
        - stride (int): Stride of conv layer.
        - pad (int): Number of padding of conv layer.
        - Other arguments are same as the Linear class.
    """
    def __init__(
        self, 
        in_dims, out_dims,
        ksize, stride, pad,
        init_mode="linear",
        init_scale=1e-3
    ):
        super().__init__()
        
        self.params["w"] = initialize(
            (out_dims, in_dims, ksize, ksize), 
            init_mode, init_scale)
        self.params["b"] = initialize(out_dims, "zero")
        
        self.in_dims = in_dims
        self.out_dims = out_dims
        self.ksize = ksize
        self.stride = stride
        self.pad = pad
    
    def forward(self, x):
        ######################################################################
        # TODO: Convolution 레이어의 forward propagation 구현.
        #
        # HINT: for-loop의 4-중첩으로 구현.
        ######################################################################
        FN, C, FH, FW = self.params["w"].shape
        self.params['x'] = x

        N, C, H, W = x.shape
        out_h = int(1 + (H + 2 * self.pad - FH) / self.stride)
        out_w = int(1 + (W + 2 * self.pad - FW) / self.stride)
        img = np.zeros((N,C,H+self.pad*2,W+self.pad*2))
        out=np.zeros((N,FN,out_h,out_w))

        for n in range(N):
            for c in range(C):
                img[n,c] = np.pad(x[n,c],((self.pad,self.pad),(self.pad,self.pad)),'constant')
            for fn in range(FN):
                for h in range(out_h):
                    for w in range(out_w):
                        start_h = h*self.stride
                        start_w = w*self.stride
                        out[n,fn,h,w] = np.sum(img[n,:,start_h:start_h+self.ksize,start_w:start_w+self.ksize]*self.params['w'][fn])
        
        for n in range(N):
            for fn in range(FN):
                out[n,fn]+=self.params['b'][fn]
        
        ######################################################################
        #                          END OF YOUR CODE                          #
        ######################################################################
        return out

    def backward(self, dout):
        ######################################################################
        # TODO: Convolution 레이어의 backward propagation 구현.
        #
        # HINT: for-loop의 4-중첩으로 구현.
        ######################################################################
        x = self.params['x']
        w_v = self.params['w']
        b = self.params['b']

        dx = np.zeros_like(x)
        dw = np.zeros_like(w_v)
        db = np.zeros_like(b)

        N, C, H, W = x.shape
        FN, C, FH, FW = w_v.shape

        
        out_h = int(1 + (H + 2 * self.pad - FH) / self.stride)
        out_w = int(1 + (W + 2 * self.pad - FW) / self.stride)

        dx_img = np.pad(dx, ((0,0),(0,0),(self.pad,self.pad),(self.pad,self.pad)),'constant')
        x_img = np.pad(x, ((0,0),(0,0),(self.pad,self.pad),(self.pad,self.pad)),'constant')

        

        for n in range(N):
            for fn in range(FN):
              
                for h in range(out_h):
                    for w in range(out_w):
                        start_h = int(h*self.stride)
                        start_w = int(w*self.stride)
                        dnum = dout[n,fn,h,w]
                
                        dx_img[n,:,start_h:start_h+self.ksize,start_w:start_w+self.ksize] += (dnum * w_v[fn])
                        dw[fn,:,:,:] += (dout[n,fn,h,w] * x_img[n,:,start_h:start_h+self.ksize,start_w:start_w+self.ksize])
                        db[fn] += dout[n,fn,h,w]

        dx = dx_img[:,:,self.pad:self.pad+H, self.pad:self.pad+W]
        ######################################################################
        #                          END OF YOUR CODE                          #
        ######################################################################
        self.grads["x"] = dx
        self.grads["w"] = dw
        self.grads["b"] = db
        return dx
    

class MaxPool2d(Layer):
    """Max pooling layer.

    Args:
        - ksize (int): Kernel size of maxpool layer.
        - stride (int): Stride of maxpool layer.
    """
    def __init__(self, ksize, stride):
        super().__init__()
        
        self.ksize = ksize
        self.stride = stride
        
    def forward(self, x):
        ######################################################################
        # TODO: Max pooling 레이어의 forward propagation 구현.
        #
        # HINT: for-loop의 2-중첩으로 구현.
        ######################################################################
        self.x = x

        N, C, H, W = x.shape
        out_h = int(1 + (H - self.ksize)/ self.stride)
        out_w = int(1 + (W - self.ksize)/ self.stride)

        out=np.zeros((N,C,out_h,out_w))

        for n in range(N):
            for c in range(C):
                for h in range(out_h):
                    for w in range(out_w):
                        start_h = h*self.stride
                        start_w = w*self.stride
                        out[n,c,h,w] = np.max(x[n,c,start_h:start_h+self.ksize,start_w:start_w+self.ksize])
        
        ######################################################################
        #                          END OF YOUR CODE                          #
        ######################################################################
        return out

    def backward(self, dout):
        ######################################################################
        # TODO: Max pooling 레이어의 backward propagation 구현.
        #
        # HINT: for-loop의 4-중첩으로 구현.
        ######################################################################
        x = self.x
        N, C, H, W = x.shape
        out_h = int(1 + (H - self.ksize)/ self.stride)
        out_w = int(1 + (W - self.ksize)/ self.stride)

        dx =  np.zeros_like(x)
        for n in range(N):
            for c in range(C):
                for h in range(out_h):
                    for w in range(out_w):
                        start_h = h*self.stride
                        start_w = w*self.stride
                        temp = x[n,c,start_h:start_h+self.ksize,start_w:start_w+self.ksize]
                        max_num = np.max(temp)
                        dx[n,c,start_h:start_h+self.ksize,start_w:start_w+self.ksize][temp==max_num] = dout[n,c,h,w]

        ######################################################################
        #                          END OF YOUR CODE                          #
        ######################################################################
        self.grads["x"] = dx
        return dx
