# A SVM file that has been hyper-tuned and 
# implemented by scikit-learn. 
# Used Backward Elimination to feature selection

import pandas as pd
import numpy as np
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score
from sklearn.metrics import classification_report,confusion_matrix
from sklearn.model_selection import GridSearchCV

col=['0','1','2','3','4','5','6','7','8','9']
df =pd.read_csv("./data/cancer_train.csv", names=col)
df_test = pd.read_csv("./data/cancer_test.csv", names=col)
X = np.array(df.iloc[:,1:])
X_test = np.array(df.iloc[:,1:])

y = np.array(df.iloc[:,0])
y_test = np.array(df_test.iloc[:,0])

current_feature = [i for i  in range(1,10)]
MAX_score =0
MAX_gamma=0
MAX_list =[]
temp_list =[]
clf = SVC()
Range = [0.01,0.1,1,10]

param_grid = {'gamma':Range}

svm_cv= GridSearchCV(clf,param_grid,cv=5)

#Backward Elimination & cross-validation
for i in range(10):
	
	for feature in current_feature:
		temp_list=[value for value in current_feature]
		temp_list.remove(feature)
		X = np.array(df.iloc[:,temp_list])
		svm_cv.fit(X,y)
			
		
		if svm_cv.best_score_ > MAX_score :
			MAX_score = svm_cv.best_score_
			MAX_gamma =svm_cv.best_params_
			MAX_list=temp_list
	if current_feature == MAX_list:
		break

	current_feature = MAX_list

# print result
print("MAX_gamma : ",MAX_gamma)
print("MAX_score : ",MAX_score)
print("MAX_list : ",MAX_list)

X_test = np.array(df_test.iloc[:,MAX_list])
X = np.array(df.iloc[:,MAX_list])
clf = SVC(gamma = MAX_gamma['gamma'])

clf.fit(X,y)
final_predict = clf.predict(X_test)

final_test = y_test
score = 100 * accuracy_score(final_test,final_predict)

print("gamma = %.3f Accuracy : %.2f %% LIST = " %(MAX_gamma['gamma'],score),MAX_list)
print("Confusion_Matrix:\n",confusion_matrix(final_test,final_predict))
print(classification_report(final_test,final_predict))
