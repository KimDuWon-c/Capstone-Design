# A KNN file that has been non hyper-tuned and 
# implemented by scikit-learn. 

import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score

col=['0','1','2','3','4','5','6','7','8','9']
df =pd.read_csv("./data/cancer_train.csv", names=col)
df_test = pd.read_csv("./data/cancer_test.csv", names=col)
	


X = np.array(df.iloc[:,1:])
X_test = np.array(df_test.iloc[:,1:])

y = np.array(df.iloc[:,0])
y_test = np.array(df_test.iloc[:,0])

knn = KNeighborsClassifier(n_neighbors=5)

knn.fit(X,y)

y_predict = knn.predict(X)
print("Train Accuracy of 5NN: %.2f %%" %(100*accuracy_score(y,y_predict)))
y_predict = knn.predict(X_test)
print("Test Accuracy of 5NN: %.2f %%" %(100*accuracy_score(y_test,y_predict)))

