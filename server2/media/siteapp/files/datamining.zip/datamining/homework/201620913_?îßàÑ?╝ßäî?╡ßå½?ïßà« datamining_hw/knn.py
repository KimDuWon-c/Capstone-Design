# A KNN file that has been implemented without scikit-learn 
# and get_distance, train, predict function.

import pandas as pd
import numpy as np
import collections
import sys

trained_matrix=[]

def get_distance(X_train, x_test,mode):

	distance =0	
	
	if mode == 'euclidean':
		distance = np.sqrt(np.sum(np.square(x_test - X_train)))
	elif mode == 'manhattan':
		distance = (np.sum(np.absolute(x_test - X_train)))
	elif mode == 'linfinite':
		distance = np.max(np.absolute(x_test - X_train))
		
	return distance
	
def train(X_train, x_test, mode):
	distance = []
	distances = []
	matrix = []
	
	for j in range(len(x_test)):
			for i in range(len(X_train)):
				# first we compute the euclidean distance
				distance = get_distance(X_train[i,:],x_test[j,:],mode)
				
				# add it to list of distances
				distances.append([distance, j,i])

			matrix.append(distances)
			distances=[]

	# sorted matrix 
	for i in range(len(matrix)):
		matrix[i] = sorted(matrix[i])
	
	global trained_matrix
	trained_matrix = matrix

	return 

def predict(y_train,k):

	global trained_matrix
	matrix=trained_matrix
	matrix_t=[]
	targets=[]

	for j in range(len(matrix)):
		for i in range(k):
			index = matrix[j][i][2]
			targets.append(y_train[index])


		matrix_t.append(sorted(targets))
		targets=[]

	# return most common target
	y_pre=[]
	for j in range(len(matrix_t)):
		Max = 0
		temp = collections.Counter(matrix_t[j]).most_common(k)
		temp2 = [temp[0][0]]
		for i in range(len(temp)):
			if temp[i][1] >= Max:
				Max=temp[i][1]
				temp2.append(temp[i][0])
			else:
				break

		y_pre.append(min(temp2))
		#y_pre.append(collections.Counter(matrix_t[j]).most_common(k)[0][0])
	return y_pre

def report(y_test,predict):
	label = []
	check =0
	
	#search label
	for i in range(len(y_test)):
		for k in range(len(label)):
			if label[k]==y_test[i]:
				check =1 
		if check==0:
			label.append(y_test[i])
		check=0

			
	label=sorted(label)

	#create confusion metrix

	confusion = [[] for i in label]

	for i in range(len(confusion)):
		confusion[i]=[0 for k in range(len(label)+1)]
		confusion[i][0] = label[i]


	for i in range(len(y_test)):
		confusion[y_test[i]][predict[i]+1]+=1


	# recall
	recall = [float(confusion[i][i+1])/sum(confusion[i][1:]) for i in range(len(confusion))]

	
	# precision
	precision=[]
	for i in range(len(label)):
		total =0
		for k in range(len(label)):
			total+=confusion[k][i+1]
		precision.append(confusion[i][i+1]/float(total))

	#accuracy
	total=0

	for i in range(len(label)):
		total+=confusion[i][i+1]

	accuracy=float(total)/len(y_test)
		

	#f1
	f1=[]

	for i in range(len(label)):
		f1.append(2*precision[i]*recall[i]/(precision[i]+recall[i]))


	#support
	support = []
	for i in range(len(label)):
		support.append(sum(confusion[i][1:]))


	report="""
		precision  recall  f1-score  support
	"""

	data ="""
	%d      %.2f       %.2f    %.2f      %d
	"""

	for i in range(len(label)):
		report+=(data%(label[i],precision[i],recall[i],f1[i],support[i]))
	
	report +="\n\tAccuracy = %.2f %%" %(accuracy*100)
	return report

def main():
	
	# setup data
	df =pd.read_csv("./data/digits_train.csv")
	col =[i for i,value in enumerate(df.iloc[0,:])] 
	df =pd.read_csv("./data/digits_train.csv", names=col)
	df_test = pd.read_csv("./data/digits_test.csv", names=col)

	X = np.array(df.iloc[:,1:])
	y = np.array(df.iloc[:,0])
	X_test = np.array(df_test.iloc[:,1:])
	y_test = np.array(df_test.iloc[:,0])

	#training
	train(X,X_test,'euclidean')
	
	#predict
	pre = predict(y,int(sys.argv[1]))

	#print report
	print(report(y_test,pre))

if __name__ == "__main__":

	main()


