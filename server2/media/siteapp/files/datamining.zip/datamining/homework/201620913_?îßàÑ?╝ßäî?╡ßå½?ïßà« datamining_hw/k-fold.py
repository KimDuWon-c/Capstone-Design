# A KNN cross-validation file that has been implemented without scikit-learn and 5-fold cross validation.
# The function print Multi-class Classification.
# It import to knn.py including function for KNN.

import knn
import pandas as pd
import numpy as np
import sys

T=0

def report(y_test,predict):
	label = []
	check =0

	#search label
	for i in range(len(y_test)):
		for k in range(len(label)):
			if label[k]==y_test[i]:
				check =1
		if check==0:
			label.append(y_test[i])
		check=0


	label=sorted(label)

	#create confusion metrix

	confusion = [[] for i in label]

	for i in range(len(confusion)):
		confusion[i]=[0 for k in range(len(label)+1)]
		confusion[i][0] = label[i]


	for i in range(len(y_test)):
		confusion[y_test[i]][predict[i]+1]+=1


	# recall
	recall = [float(confusion[i][i+1])/sum(confusion[i][1:]) for i in range(len(confusion))]


	# precision
	precision=[]
	for i in range(len(label)):
		total =0
		for k in range(len(label)):
			total+=confusion[k][i+1]
		precision.append(confusion[i][i+1]/float(total))

	#accuracy
	total=0

	for i in range(len(label)):
		total+=confusion[i][i+1]

	accuracy=float(total)/len(y_test)

	
	#f1
	f1=[]

	for i in range(len(label)):
		try:
			f1.append(2*precision[i]*recall[i]/(precision[i]+recall[i]))
		except:
			f1.append(0)

	#support
	support = []
	for i in range(len(label)):
		support.append(sum(confusion[i][1:]))


	report="""
		precision  recall  f1-score  support
	"""

	data ="""
	%d      %.2f       %.2f    %.2f      %d
	"""

	for i in range(len(label)):
		report+=(data%(label[i],precision[i],recall[i],f1[i],support[i]))

	report +="\n\tAccuracy = %.2f %%" %(accuracy*100)

	global T
	T+=(accuracy*100)

	return report

def main():
	global total
	# setup data
	df =pd.read_csv("./data/digits_train.csv")
	col =[i for i,value in enumerate(df.iloc[0,:])]
	df =pd.read_csv("./data/digits_train.csv", names=col)
	df_test = pd.read_csv("./data/digits_test.csv", names=col)

	X = np.array(df.iloc[:,1:])
	y = np.array(df.iloc[:,0])
	X_test = np.array(df_test.iloc[:,1:])
	y_test = np.array(df_test.iloc[:,0])
	
	length = int(len(X)/5)
	sel_test = list(range(length))	
	
	for i in range(5):

		sel_temp=list(range(len(X)))
		
		for k in range(length):
			sel_test = [value+(length*i)for value in range(length)]
			
		X_test = np.array(df.iloc[sel_test,1:])
		y_test = np.array(df.iloc[sel_test,0])
	
		for k in sel_test:
			sel_temp.remove(k)

		X_train = np.array(df.iloc[sel_temp,1:])
		y_train = np.array(df.iloc[sel_temp,0])
		
		knn.train(X_train,X_test,'euclidean')
		
		pre = knn.predict(y_train,int(sys.argv[1]))

		print(report(y_test,pre))

	print("average accuracy = %.2f %%"%(T/5))

	"""
	#training
	knn.train(X,X_test,'euclidean')

	#predict
	pre = knn.predict(y,int(sys.argv[1]))

	#print report
	print(report(y_test,pre))
	"""
if __name__ == "__main__":

	main()
