# A DecisionTree file that has been hyper-tuned and 
# implemented by scikit-learn. 
# Used Backward Elimination to feature selection

import pandas as pd
import numpy as np
from sklearn import tree
from sklearn.metrics import accuracy_score
from sklearn.metrics import classification_report,confusion_matrix
from sklearn.model_selection import GridSearchCV

col=['0','1','2','3','4','5','6','7','8','9']
df =pd.read_csv("./data/cancer_train.csv", names=col)
df_test = pd.read_csv("./data/cancer_test.csv", names=col)
X = np.array(df.iloc[:,1:])
X_test = np.array(df.iloc[:,1:])

y = np.array(df.iloc[:,0])
y_test = np.array(df_test.iloc[:,0])

current_feature = [i for i  in range(1,10)]
MAX_score =0
MAX_k=0
MAX_list =[]
temp_list =[]
clf = tree.DecisionTreeClassifier()
param_grid = {'max_depth':np.arange(1,20)}
tree_cv= GridSearchCV(clf,param_grid,cv=5)

#In case of classifier like knn the parameter to be tuned is n_neighbors
for i in range(10):
	
	for feature in current_feature:
		temp_list=[value for value in current_feature]
		temp_list.remove(feature)
		X = np.array(df.iloc[:,temp_list])
		tree_cv.fit(X,y)
			
		
		if tree_cv.best_score_ > MAX_score :
			MAX_score = tree_cv.best_score_
			MAX_depth =tree_cv.best_params_
			MAX_list=temp_list
	if current_feature == MAX_list:
		break

	current_feature = MAX_list

print("MAX_depth : ",MAX_depth)
print("MAX_score : ",MAX_score)
print("MAX_list : ",MAX_list)

X_test = np.array(df_test.iloc[:,MAX_list])
X = np.array(df.iloc[:,MAX_list])

clf = tree.DecisionTreeClassifier(max_depth=MAX_depth['max_depth'])
clf.fit(X,y)
final_predict = clf.predict(X_test)

final_test = y_test
score = 100 * accuracy_score(final_test,final_predict)

print("MAX_depth = %d , Accuracy : %.2f %% LIST = " %(MAX_depth['max_depth'],score),MAX_list)
print("Confusion_Matrix:\n",confusion_matrix(final_test,final_predict))
print(classification_report(final_test,final_predict))
