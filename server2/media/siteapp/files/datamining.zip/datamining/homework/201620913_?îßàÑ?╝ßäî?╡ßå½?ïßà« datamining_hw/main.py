# A KNN main file that has been implemented without scikit-learn and report function.
# The function print Multi-class Classification.
# It import to knn.py including function for KNN

import knn
import pandas as pd
import numpy as np
import sys


def report(y_test,predict):
	label = []
	check =0

	#search label
	for i in range(len(y_test)):
		for k in range(len(label)):
			if label[k]==y_test[i]:
				check =1
		if check==0:
			label.append(y_test[i])
		check=0


	label=sorted(label)

	#create confusion metrix

	confusion = [[] for i in label]

	for i in range(len(confusion)):
		confusion[i]=[0 for k in range(len(label)+1)]
		confusion[i][0] = label[i]


	for i in range(len(y_test)):
		confusion[y_test[i]][predict[i]+1]+=1


	# recall
	recall = [float(confusion[i][i+1])/sum(confusion[i][1:]) for i in range(len(confusion))]


	# precision
	precision=[]
	for i in range(len(label)):
		total =0
		for k in range(len(label)):
			total+=confusion[k][i+1]
		precision.append(confusion[i][i+1]/float(total))

	#accuracy
	total=0

	for i in range(len(label)):
		total+=confusion[i][i+1]

	accuracy=float(total)/len(y_test)


	#f1
	f1=[]

	for i in range(len(label)):
		f1.append(2*precision[i]*recall[i]/(precision[i]+recall[i]))


	#support
	support = []
	for i in range(len(label)):
		support.append(sum(confusion[i][1:]))


	report="""
		precision  recall  f1-score  support
	"""

	data ="""
	%d      %.2f       %.2f    %.2f      %d
	"""

	for i in range(len(label)):
		report+=(data%(label[i],precision[i],recall[i],f1[i],support[i]))

	report +="\n\tAccuracy = %.2f %%" %(accuracy*100)
	return report

def main():
	# setup data
	if(len(sys.argv)<2):
		print("Please input 'python main.py (k number) '")
		exit()

	df =pd.read_csv("./data/digits_train.csv")
	col =[i for i,value in enumerate(df.iloc[0,:])]
	df =pd.read_csv("./data/digits_train.csv", names=col)
	df_test = pd.read_csv("./data/digits_test.csv", names=col)

	X = np.array(df.iloc[:,1:])
	y = np.array(df.iloc[:,0])
	X_test = np.array(df_test.iloc[:,1:])
	y_test = np.array(df_test.iloc[:,0])

	#training
	knn.train(X,X_test,'euclidean')

	#predict
	pre = knn.predict(y,int(sys.argv[1]))

	#print report
	print("Test:")
	print(report(y_test,pre))
	
	knn.train(X,X,'euclidean')

	pre = knn.predict(y,int(sys.argv[1]))

	print("Train:")
	print(report(y,pre))

if __name__ == "__main__":

	main()
